// Post Test 5 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest5pbo.model;


public class Pengeluaran extends Transaksi {
    public Pengeluaran(int id, String tanggal, String keterangan,
                       String kategori, String metodePembayaran, double jumlah) {
        super(id, tanggal, keterangan, "Pengeluaran", kategori, metodePembayaran, jumlah);
    }

    // Overriding: kunci jenis agar konsisten
    @Override
    public String getJenis() { return "Pengeluaran"; }

    @Override
    public void setJenis(String jenis) {}

    // Overriding abstract method
    @Override
    protected int tandaSaldo() { return -1; }
}
