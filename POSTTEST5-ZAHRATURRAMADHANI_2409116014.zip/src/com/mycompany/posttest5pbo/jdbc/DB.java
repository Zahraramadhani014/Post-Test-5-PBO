// Post Test 5 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest5pbo.jdbc;


import java.sql.*;

public class DB {
    private static final String URL = "jdbc:mysql://localhost:3306/pocket_guard";
    private static final String USER = "root";   
    private static final String PASS = "";        

    static {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new RuntimeException("Driver MySQL tidak ditemukan", e); }
    }

    public static Connection get() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
