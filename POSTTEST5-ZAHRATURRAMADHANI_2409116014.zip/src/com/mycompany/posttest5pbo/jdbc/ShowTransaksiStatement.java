// Post Test 5 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest5pbo.jdbc;


import java.sql.*;

public class ShowTransaksiStatement {
    public static void showAll() {
        String sql = "SELECT id, tanggal, jenis, kategori, metode, jumlah, keterangan FROM transaksi ORDER BY id";
        int[] w = {4,12,12,15,12,15,30};
        try (Connection c = DB.get(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            System.out.println();
            System.out.println(garis(w));
            System.out.printf("| %-" + w[0] + "s | %-" + w[1] + "s | %-" + w[2] + "s | %-" + w[3] + "s | %-" + w[4] + "s | %-" + w[5] + "s | %-" + w[6] + "s |\n",
                    "ID","Tanggal","Jenis","Kategori","Metode","Jumlah","Keterangan");
            System.out.println(garis(w));

            boolean empty = true;
            while (rs.next()) {
                empty = false;
                String ket = rs.getString("keterangan");
                ket = ket.length() > w[6] ? ket.substring(0, w[6]-3) + "..." : ket;
                String jumlah = "Rp " + String.format("%,.0f", rs.getDouble("jumlah")).replace(',', '.');
                System.out.printf("| %-" + w[0] + "d | %-" + w[1] + "s | %-" + w[2] + "s | %-" + w[3] + "s | %-" + w[4] + "s | %-" + w[5] + "s | %-" + w[6] + "s |\n",
                        rs.getInt("id"), rs.getDate("tanggal"), rs.getString("jenis"),
                        rs.getString("kategori"), rs.getString("metode"), jumlah, ket);
            }
            if (empty) {
                System.out.printf("| %-" + (w[0]+w[1]+w[2]+w[3]+w[4]+w[5]+w[6] + 18) + "s |\n", "Belum ada data transaksi");
            }
            System.out.println(garis(w));
        } catch (SQLException e) {
            System.out.println("Gagal mengambil data via Statement: " + e.getMessage());
        }
        System.out.println();
    }

    private static String garis(int[] widths) {
        StringBuilder sb = new StringBuilder(); sb.append('+');
        for (int w : widths) { for (int i=0;i<w+2;i++) sb.append('-'); sb.append('+'); }
        return sb.toString();
    }
}
