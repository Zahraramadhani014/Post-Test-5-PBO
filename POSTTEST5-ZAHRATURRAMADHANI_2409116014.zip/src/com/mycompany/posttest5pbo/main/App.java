// Post Test 5 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest5pbo.main;

import com.mycompany.posttest5pbo.service.TransaksiService;
import java.util.logging.Level;
import java.util.logging.Logger;

public class App {
    public static void main(String[] args) {
        System.setProperty("org.jboss.logging.provider", "jdk");
        Logger.getLogger("org.hibernate").setLevel(Level.SEVERE);
        Logger.getLogger("org.hibernate.tool.schema").setLevel(Level.SEVERE);
        Logger.getLogger("org.hibernate.engine.jdbc").setLevel(Level.SEVERE);

        TransaksiService svc = new TransaksiService();
        svc.seed();

        int pilih;
        do {
            System.out.println("+=======================================+");
            System.out.println("|     SELAMAT DATANG DI POCKET GUARD    |");
            System.out.println("| Aplikasi Catatan Keuangan Harian Anda |");
            System.out.println("+=======================================+");
            System.out.println("|              MENU UTAMA               |");
            System.out.println("+=======================================+");
            System.out.println("| 1. Tambah Catatan Keuangan            |");
            System.out.println("| 2. Lihat Semua Catatan Keuangan       |");
            System.out.println("| 3. Ubah Catatan Keuangan              |");
            System.out.println("| 4. Hapus Catatan Keuangan             |");
            System.out.println("| 5. Ringkasan Saldo                    |");
            System.out.println("| 6. Filter dan Search                  |");
            System.out.println("| 7. Set Batas Pengeluaran              |");
            System.out.println("| 8. Keluar                             |");
            System.out.println("+=======================================+");
            System.out.print("-> Silakan Pilih Menu Yang Diinginkan [1-8]: ");

            pilih = SafeInput.safeNextInt();

            switch (pilih) {
                case 1 -> svc.tambahCatatan();
                case 2 -> svc.lihatSemuaCatatan();
                case 3 -> svc.ubahCatatan();
                case 4 -> svc.hapusCatatan();
                case 5 -> svc.ringkasanSaldo();
                case 6 -> svc.menuFilter();
                case 7 -> svc.setBatasPengeluaran();
                case 8 -> {
                    System.out.println("\n+=================================================+");
                    System.out.println("|   Terima kasih telah menggunakan POCKET GUARD   |");
                    System.out.println("|  Semoga keuangan Anda selalu aman & terjaga !!  |");
                    System.out.println("+=================================================+");
                }
                default -> {
                    System.out.println("\n+=================================================+");
                    System.out.println("|    Pilihan tidak valid. Silakan coba lagi!!!    |");
                    System.out.println("+=================================================+\n");
                }
            }
        } while (pilih != 8);
    }
}

class SafeInput {
    private static final java.util.Scanner sc = new java.util.Scanner(System.in);
    static int safeNextInt(){
        while(true){
            try { return Integer.parseInt(sc.nextLine().trim()); }
            catch(NumberFormatException e){ System.out.print("Harus angka! Silakan input ulang: "); }
        }
    }
}
