// Post Test 5 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest5pbo.service;

import com.mycompany.posttest5pbo.model.*;
import com.mycompany.posttest5pbo.orm.entity.TransaksiEntity;
import com.mycompany.posttest5pbo.orm.repo.TransaksiRepository;
import com.mycompany.posttest5pbo.jdbc.ShowTransaksiStatement;

import java.sql.Date;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class TransaksiService {

    private final Scanner input = new Scanner(System.in);
    private final TransaksiRepository repo = new TransaksiRepository();
    private double batasPengeluaranBulanan = 0;

    public void seed() {}

    // Helper konversi Entity <-> Model 
    private Transaksi toModel(TransaksiEntity e) {
        if (e.getJenis() == TransaksiEntity.JenisTransaksi.Pemasukan)
            return new Pemasukan(e.getId(), e.getTanggal().toString(), e.getKeterangan(),
                    e.getKategori(), e.getMetodePembayaran(), e.getJumlah().doubleValue());
        else
            return new Pengeluaran(e.getId(), e.getTanggal().toString(), e.getKeterangan(),
                    e.getKategori(), e.getMetodePembayaran(), e.getJumlah().doubleValue());
    }
    private List<Transaksi> toModels(List<TransaksiEntity> list) {
        return list.stream().map(this::toModel).collect(Collectors.toList());
    }

    // MENU CRUD
    // TAMBAH CATATAN
    public void tambahCatatan() {
        String ulang;
        do {
            header("TAMBAH CATATAN KEUANGAN");
            String tanggal = inputTanggalWajib("-> Silakan Input Tanggal (Format yyyy-mm-dd): ");
            String keterangan = inputWajib("-> Silakan Input Keterangannya : ");
            String jenis = inputPilihanWajib("-> Silakan Input Jenis Transaksinya (Pemasukan/Pengeluaran): ",
                    new String[]{"Pemasukan", "Pengeluaran"});
            String kategori = inputPilihanWajib("-> Silakan Input Kategori (gaji, makan, transportasi, hiburan, belanja, tabungan, tagihan): ",
                    new String[]{"Gaji", "Makan", "Transportasi", "Hiburan", "Belanja", "Tabungan", "Tagihan"});
            String metode = inputPilihanWajib("-> Silakan Input Metode Pembayaran (Cash/E-Wallet/Transfer): ",
                    new String[]{"Cash", "E-Wallet", "Transfer"});
            double jumlah = inputDoubleWajib("-> Silakan Input Nominal Transaksinya : ");

            TransaksiEntity e = new TransaksiEntity();
            e.setTanggal(Date.valueOf(tanggal));
            e.setKeterangan(keterangan);
            e.setJenis(toJenisEnum(jenis)); 
            e.setKategori(kategori);
            e.setMetodePembayaran(metode);
            e.setJumlah(java.math.BigDecimal.valueOf(jumlah));
            repo.insert(e);

            System.out.println("\nData berhasil ditambahkan");

            if (batasPengeluaranBulanan > 0) {
                double totalKeluar = repo.sumByJenis(TransaksiEntity.JenisTransaksi.Pengeluaran); // enum
                if (totalKeluar > batasPengeluaranBulanan) {
                    System.out.println("\nPeringatan: Pengeluaran melebihi batas bulanan (" +
                            formatRupiah(batasPengeluaranBulanan) + "). Total saat ini: " +
                            formatRupiah(totalKeluar));
                }
            }
            tampilkanTabel(repo.findAll());

            System.out.print("\nApakah ingin menambah catatan lagi? (Y/T): ");
            ulang = input.nextLine(); System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }

    // LIHAT CATATAN
    public void lihatSemuaCatatan() {
        ShowTransaksiStatement.showAll(); 
        tampilkanTabel(repo.findAll());
    }
    
    // UBAH CATATAN
    public void ubahCatatan() {
        String ulang;
        do {
            header("UBAH CATATAN KEUANGAN");
            tampilkanTabel(repo.findAll());
            System.out.print("-> Masukkan ID Yang Ingin Diubah: ");
            int id = safeNextInt();
            TransaksiEntity e = repo.findById(id);
            if (e == null) {
                System.out.println("\nID tidak ditemukan");
            } else {
                e.setTanggal(Date.valueOf(inputStringOpsional("-> Input Tanggal baru (yyyy-mm-dd): ",
                        e.getTanggal().toString())));
                e.setKeterangan(inputStringOpsional("-> Input Keterangan baru: ", e.getKeterangan()));
                String jenisBaru = inputStringOpsional("-> Input Jenis baru (Pemasukan/Pengeluaran): ",
                        e.getJenis().name());
                e.setJenis(toJenisEnum(jenisBaru));
                e.setKategori(inputStringOpsional("-> Input Kategori baru: ", e.getKategori()));
                e.setMetodePembayaran(inputStringOpsional("-> Input Metode Pembayaran baru: ", e.getMetodePembayaran()));
                e.setJumlah(java.math.BigDecimal.valueOf(inputDoubleOpsional("-> Input Nominal Transaksi baru: ",
                        e.getJumlah().doubleValue())));
                repo.update(e);
                System.out.println("\nData berhasil diubah");
            }
            tampilkanTabel(repo.findAll());
            System.out.print("\nApakah ingin mengubah catatan lagi? (Y/T): ");
            ulang = input.nextLine(); System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }

    // HAPUS CATATAN
    public void hapusCatatan() {
        String ulang;
        do {
            header("HAPUS CATATAN KEUANGAN");
            tampilkanTabel(repo.findAll());
            Integer id = inputIntAtauBatal("-> Masukkan ID yang ingin dihapus (Enter=batalkan): ");
            if (id == null) { System.out.println("\nPenghapusan dibatalkan"); return; }
            TransaksiEntity e = repo.findById(id);
            if (e == null) System.out.println("\nID tidak ditemukan");
            else {
                System.out.print("Apakah Anda yakin ingin menghapus ID " + id + " ? (Y/T): ");
                String ya = input.nextLine().trim().toLowerCase();
                if (ya.equals("y")) { repo.delete(e); System.out.println("\nData berhasil dihapus"); }
                else System.out.println("\nPenghapusan dibatalkan");
            }
            System.out.print("\nApakah ingin menghapus catatan lagi? (Y/T): ");
            ulang = input.nextLine(); System.out.println();
        } while (ulang.equalsIgnoreCase("Y"));
    }

    //Ringkasan & Batas
    public void ringkasanSaldo() {
        double totalMasuk  = repo.sumByJenis(TransaksiEntity.JenisTransaksi.Pemasukan);   // enum
        double totalKeluar = repo.sumByJenis(TransaksiEntity.JenisTransaksi.Pengeluaran); // enum
        double saldo = totalMasuk - totalKeluar;

        header("RINGKASAN SALDO");
        System.out.println("Total Pemasukan   : " + formatRupiah(totalMasuk));
        System.out.println("Total Pengeluaran : " + formatRupiah(totalKeluar));
        System.out.println("Saldo             : " + formatRupiah(saldo));
        System.out.println("================================================================================");
        if (totalKeluar > totalMasuk) {
            System.out.println("\nCatatan: Pengeluaran lebih besar dari pemasukan. Harap bijak mengatur keuangan\n");
        }
        tungguKembali();
    }

    public void setBatasPengeluaran() {
        header("SET BATAS PENGELUARAN BULANAN");
        System.out.println("Batas saat ini : " + (batasPengeluaranBulanan <= 0 ? "— (tidak diaktifkan)" : formatRupiah(batasPengeluaranBulanan)));
        double val = inputDoubleNonNegatif("-> Masukkan batas baru (ketik 0 untuk menonaktifkan): ");
        batasPengeluaranBulanan = val;

        if (batasPengeluaranBulanan == 0) {
            System.out.println("\nBatas pengeluaran bulanan dinonaktifkan");
        } else {
            System.out.println("\nBatas disetel: " + formatRupiah(batasPengeluaranBulanan));
            double totalKeluar = repo.sumByJenis(TransaksiEntity.JenisTransaksi.Pengeluaran); // enum
            double sisa = batasPengeluaranBulanan - totalKeluar;
            System.out.println("Total pengeluaran saat ini: " + formatRupiah(totalKeluar));
            System.out.println("Sisa ruang anggaran       : " + formatRupiah(sisa));
            if (sisa < 0) System.out.println("Peringatan: Pengeluaran sudah melebihi batas !!!");
        }
        tungguKembali();
    }

    // Filter/Search (via ORM) 
    public void menuFilter() {
        int pilih;
        do {
            System.out.println("\n===========================================================================");
            System.out.println("|                             MENU FILTER/SEARCH                          |");
            System.out.println("===========================================================================");
            System.out.println("| 1. Filter per Jenis (Pemasukan/Pengeluaran)                             |");
            System.out.println("| 2. Filter per Kategori                                                  |");
            System.out.println("| 3. Filter per Metode Pembayaran                                         |");
            System.out.println("| 4. Search (cari di keterangan)                                          |");
            System.out.println("| 5. Kembali                                                              |");
            System.out.println("=========================================================================== ");
            System.out.print("Pilih [1-5]: ");
            pilih = safeNextInt();

            switch (pilih) {
                case 1 -> filterByJenis();
                case 2 -> filterByKategori();
                case 3 -> filterByMetode();
                case 4 -> searchByKeterangan();
                case 5 -> System.out.println();
                default -> System.out.println("Pilihan tidak valid\n");
            }
        } while (pilih != 5);
    }

    private void filterByJenis() {
        System.out.println("\n=================================================================================");
        System.out.println("|                            Filter berdasarkan Jenis                           |");
        System.out.println("=================================================================================");
        String j = inputPilihanWajib("-> Masukkan Jenis (Pemasukan/Pengeluaran): ",
                new String[]{"Pemasukan", "Pengeluaran"});
        tampilkanTabel(repo.filterEq("jenis", j));
    }
    private void filterByKategori() {
        System.out.println("\n=================================================================================");
        System.out.println("|                           Filter berdasarkan Kategori                         |");
        System.out.println("=================================================================================");
        String k = inputPilihanWajib("-> Masukkan Kategori (gaji, makan, transportasi, hiburan, belanja, tabungan, tagihan): ",
                new String[]{"Gaji", "Makan", "Transportasi", "Hiburan", "Belanja", "Tabungan", "Tagihan"});
        tampilkanTabel(repo.filterEq("kategori", k));
    }
    private void filterByMetode() {
        System.out.println("\n=================================================================================");
        System.out.println("|                       Filter berdasarkan Metode Pembayaran                    |");
        System.out.println("=================================================================================");
        String m = inputPilihanWajib("-> Masukkan Metode (Cash/E-Wallet/Transfer): ",
                new String[]{"Cash", "E-Wallet", "Transfer"});
        tampilkanTabel(repo.filterEq("metodePembayaran", m));
    }
    private void searchByKeterangan() {
        System.out.println("\n=================================================================================");
        System.out.println("|                                SEARCH KETERANGAN                              |");
        System.out.println("=================================================================================");
        String q = inputWajib("-> Kata kunci: ").toLowerCase();
        tampilkanTabel(repo.searchKeterangan(q));
    }

    // Tabel & util (adapt list<entity>) 
    public void tampilkanTabel(List<com.mycompany.posttest5pbo.orm.entity.TransaksiEntity> entities) {
        List<Transaksi> data = toModels(entities);
        int[] w = {4, 12, 12, 15, 12, 15, 30};
        System.out.println();
        System.out.println(garis(w));
        System.out.printf("| %-" + w[0] + "s | %-" + w[1] + "s | %-" + w[2] + "s | %-" + w[3] + "s | %-" + w[4] + "s | %-" + w[5] + "s | %-" + w[6] + "s |\n",
                "ID", "Tanggal", "Jenis", "Kategori", "Metode", "Jumlah", "Keterangan");
        System.out.println(garis(w));
        if (data.isEmpty()) {
            System.out.printf("| %-" + (w[0]+w[1]+w[2]+w[3]+w[4]+w[5]+w[6] + 18) + "s |\n", "Belum ada data transaksi");
        } else {
            for (Transaksi t : data) {
                String jumlahStr = formatRupiah(t.getJumlah());
                String ket = t.getKeterangan().length() > w[6] ? t.getKeterangan().substring(0, w[6]-3) + "..." : t.getKeterangan();
                System.out.printf("| %-" + w[0] + "d | %-" + w[1] + "s | %-" + w[2] + "s | %-" + w[3] + "s | %-" + w[4] + "s | %-" + w[5] + "s | %-" + w[6] + "s |\n",
                        t.getId(), t.getTanggal(), t.getJenis(), t.getKategori(), t.getMetodePembayaran(), jumlahStr, ket);
            }
        }
        System.out.println(garis(w));
        tungguKembali();
    }

    private String garis(int[] widths){ StringBuilder sb=new StringBuilder().append('+');
        for(int w:widths){ for(int i=0;i<w+2;i++) sb.append('-'); sb.append('+'); } return sb.toString(); }

    private String formatRupiah(double nilai){ String s=String.format("%,.0f", nilai).replace(',', '.'); return "Rp " + s; }

    // Validasi & input helper
    private final Pattern TANGGAL = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");
    private String inputWajib(String p){ while(true){ System.out.print(p); String v=input.nextLine().trim(); if(!v.isEmpty()) return v; System.out.println("Tidak boleh kosong. Coba lagi");}}
    private String inputTanggalWajib(String p){ while(true){ String v=inputWajib(p); if(TANGGAL.matcher(v).matches()) return v; System.out.println("Format tanggal harus yyyy-mm-dd");}}
    private String inputPilihanWajib(String p, String[] allowed){ while(true){ String v=inputWajib(p); for(String a:allowed){ if(a.equalsIgnoreCase(v)) return a; } System.out.println("Pilihan tidak valid. Pilihan yang valid: " + String.join("/", allowed));}}
    private double inputDoubleWajib(String p){ while(true){ System.out.print(p); String v=input.nextLine().trim(); if(v.isEmpty()){ System.out.println("Tidak boleh kosong. Coba lagi"); continue;} try{ return Double.parseDouble(v);} catch(NumberFormatException e){ System.out.println("Harus angka. Coba lagi"); }}}
    private String inputStringOpsional(String p, String old){ System.out.print(p); String v=input.nextLine(); return v.isEmpty()? old : v; }
    private double inputDoubleOpsional(String p, double old){ System.out.print(p); while(true){ String v=input.nextLine().trim(); if(v.isEmpty()) return old; try{ return Double.parseDouble(v);} catch(NumberFormatException e){ System.out.print("Harus angka! Ulangi: "); } } }
    private int safeNextInt(){ while(true){ try{ return Integer.parseInt(input.nextLine().trim()); } catch(NumberFormatException e){ System.out.print("Harus angka! Silakan input ulang: "); } } }
    private void tungguKembali(){ int k; do { System.out.print("-> Ketik 0 untuk kembali: "); k=safeNextInt(); } while(k!=0); System.out.println(); }
    private Integer inputIntAtauBatal(String p){ while(true){ System.out.print(p); String s=input.nextLine().trim(); if(s.isEmpty()) return null; try{ return Integer.parseInt(s);} catch(NumberFormatException e){ System.out.println("Harus angka! Coba lagi"); } } }
    private void header(String t){ System.out.println("\n================================================================================="); System.out.println(center(t,81)); System.out.println("================================================================================="); }
    private String center(String text,int width){ if(text==null) text=""; if(text.length()>=width) return text; int pad=(width-text.length())/2; StringBuilder sb=new StringBuilder(); for(int i=0;i<pad;i++) sb.append(' '); sb.append(text); return sb.toString(); }

    private double inputDoubleNonNegatif(String prompt){
        while(true){
            System.out.print(prompt);
            String v = input.nextLine().trim();
            if(v.isEmpty()){
                System.out.println("Tidak boleh kosong. Coba lagi");
                continue;
            }
            try{
                double d = Double.parseDouble(v);
                if(d < 0){
                    System.out.println("Tidak boleh negatif. Coba lagi");
                    continue;
                }
                return d;
            }catch(NumberFormatException e){
                System.out.println("Harus angka. Coba lagi");
            }
        }
    }

    // Konversi string input user ke enum entity
    private TransaksiEntity.JenisTransaksi toJenisEnum(String s){
        return (s != null && s.equalsIgnoreCase("Pemasukan"))
                ? TransaksiEntity.JenisTransaksi.Pemasukan
                : TransaksiEntity.JenisTransaksi.Pengeluaran;
    }
}
