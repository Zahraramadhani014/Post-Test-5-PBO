// Post Test 5 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest5pbo.orm.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

@Entity
@Table(name = "transaksi")
public class TransaksiEntity {
    public static enum JenisTransaksi { Pemasukan, Pengeluaran }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private Date tanggal;

    @Column(nullable = false, length = 255)
    private String keterangan;

    @Enumerated(EnumType.STRING)
    @Column(name = "jenis",
            nullable = false,
            columnDefinition = "ENUM('Pemasukan','Pengeluaran')")
    private JenisTransaksi jenis;

    @Column(nullable = false, length = 30)
    private String kategori;

    @Column(name = "metode", nullable = false, length = 20)
    private String metodePembayaran;

    @Column(nullable = false, precision = 15, scale = 2)
    private BigDecimal jumlah;

    // getters dan setters
    public Integer getId() { return id; }
    public Date getTanggal() { return tanggal; }
    public String getKeterangan() { return keterangan; }
    public JenisTransaksi getJenis() { return jenis; }
    public String getKategori() { return kategori; }
    public String getMetodePembayaran() { return metodePembayaran; }
    public BigDecimal getJumlah() { return jumlah; }

    public void setId(Integer id) { this.id = id; }
    public void setTanggal(Date tanggal) { this.tanggal = tanggal; }
    public void setKeterangan(String keterangan) { this.keterangan = keterangan; }
    public void setJenis(JenisTransaksi jenis) { this.jenis = jenis; }
    public void setKategori(String kategori) { this.kategori = kategori; }
    public void setMetodePembayaran(String metodePembayaran) { this.metodePembayaran = metodePembayaran; }
    public void setJumlah(BigDecimal jumlah) { this.jumlah = jumlah; }
}
