// Post Test 5 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest5pbo.orm.repo;

import com.mycompany.posttest5pbo.orm1.HibernateUtil;
import com.mycompany.posttest5pbo.orm.entity.TransaksiEntity;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.math.BigDecimal;
import java.util.List;

public class TransaksiRepository {

    public List<TransaksiEntity> findAll() {
        try (Session s = HibernateUtil.get().openSession()) {
            return s.createQuery("from TransaksiEntity order by id", TransaksiEntity.class).list();
        }
    }

    public TransaksiEntity findById(int id) {
        try (Session s = HibernateUtil.get().openSession()) {
            return s.get(TransaksiEntity.class, id);
        }
    }

    public void insert(TransaksiEntity e) {
        try (Session s = HibernateUtil.get().openSession()) {
            Transaction tx = s.beginTransaction();
            s.save(e);
            tx.commit();
        }
    }

    public void update(TransaksiEntity e) {
        try (Session s = HibernateUtil.get().openSession()) {
            Transaction tx = s.beginTransaction();
            s.update(e);
            tx.commit();
        }
    }

    public void delete(TransaksiEntity e) {
        try (Session s = HibernateUtil.get().openSession()) {
            Transaction tx = s.beginTransaction();
            s.delete(e);
            tx.commit();
        }
    }

    public double sumByJenis(TransaksiEntity.JenisTransaksi jenis) {
        try (Session s = HibernateUtil.get().openSession()) {
            BigDecimal total = s.createQuery(
                    "select coalesce(sum(t.jumlah), 0) from TransaksiEntity t where t.jenis = :j",
                    BigDecimal.class)
                .setParameter("j", jenis)
                .uniqueResult();
            return total == null ? 0.0 : total.doubleValue();
        }
    }

  
    public double sumByJenis(String jenis) {
        return sumByJenis(toJenisEnum(jenis));
    }

    public List<TransaksiEntity> filterEq(String field, String val) {
        try (Session s = HibernateUtil.get().openSession()) {
            if ("jenis".equalsIgnoreCase(field)) {
                return s.createQuery(
                        "from TransaksiEntity t where t.jenis = :v order by id",
                        TransaksiEntity.class)
                    .setParameter("v", toJenisEnum(val))
                    .list();
            }
            return s.createQuery(
                        "from TransaksiEntity t where lower(t." + field + ") = :v order by id",
                        TransaksiEntity.class)
                    .setParameter("v", val.toLowerCase())
                    .list();
        }
    }

    public List<TransaksiEntity> searchKeterangan(String q) {
        try (Session s = HibernateUtil.get().openSession()) {
            return s.createQuery(
                        "from TransaksiEntity t where lower(t.keterangan) like :q order by id",
                        TransaksiEntity.class)
                    .setParameter("q", "%" + q.toLowerCase() + "%")
                    .list();
        }
    }

   
    private TransaksiEntity.JenisTransaksi toJenisEnum(String s) {
        if (s != null && s.equalsIgnoreCase("Pemasukan")) {
            return TransaksiEntity.JenisTransaksi.Pemasukan;
        }
        return TransaksiEntity.JenisTransaksi.Pengeluaran;
    }
}
